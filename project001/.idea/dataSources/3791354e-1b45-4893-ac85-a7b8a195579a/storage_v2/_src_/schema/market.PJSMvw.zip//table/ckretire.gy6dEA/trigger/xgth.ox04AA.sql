create definer = root@localhost trigger xgth
    after UPDATE
    on ckretire
    for each row
BEGIN
update kcxx set num=num+old.num-new.num where proid=new.proid;
end;

