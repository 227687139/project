create definer = root@localhost trigger xglb
    after UPDATE
    on type
    for each row
begin
update product set protype=new.typename where protype=old.typename;
end;

