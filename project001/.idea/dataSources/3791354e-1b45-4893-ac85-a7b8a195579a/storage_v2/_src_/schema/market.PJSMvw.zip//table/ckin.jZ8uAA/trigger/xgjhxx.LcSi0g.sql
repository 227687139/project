create definer = root@localhost trigger xgjhxx
    after UPDATE
    on ckin
    for each row
begin
UPDATE kcxx set num=num+new.num-old.num where proid=new.proid;
end;

