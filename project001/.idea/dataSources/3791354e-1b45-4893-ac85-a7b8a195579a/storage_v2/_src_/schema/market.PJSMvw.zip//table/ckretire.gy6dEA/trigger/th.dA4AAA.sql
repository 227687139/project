create definer = root@localhost trigger th
    after INSERT
    on ckretire
    for each row
BEGIN
UPDATE kcxx set num=num-new.num where proid=new.proid;
end;

